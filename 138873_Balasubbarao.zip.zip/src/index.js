//Import SASS file
import sass from './sass/main.scss';
import css from './css/icon-font.css';

//import js files
import jss from './js/entry.js';