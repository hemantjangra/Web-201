$('#checkVegetarian, #checknonvegetarian, #checksnacks, #checkbeverages').click(function () {
    var checkVegetarian = $('#checkVegetarian').prop('checked');
    var checknonvegetarian = $('#checknonvegetarian').prop('checked');
    var checksnacks = $('#checksnacks').prop('checked');
    var checkbeverages = $('#checkbeverages').prop('checked');

    if (checkVegetarian && !(checknonvegetarian) && !(checksnacks) && !(checkbeverages)) {
        $("#vegetarian").show();
        $("#non-vegetarian,  #beverages, #snacks").hide();
    }
    else if (checkVegetarian && checknonvegetarian && !(checksnacks) && !(checkbeverages)) {
        $("#vegetarian, #non-vegetarian").show();
        $("#snacks, #beverages").hide();
    }
    else if (checkVegetarian && checknonvegetarian && checksnacks && !(checkbeverages)) {
        $("#vegetarian, #non-vegetarian, #snacks").show();
        $("#beverages").hide();
    }
    else if ((checkVegetarian && checknonvegetarian && checksnacks && checkbeverages) || (!(checkVegetarian) && !(checknonvegetarian) && !(checksnacks)) && !(checkbeverages)) {
        $("#vegetarian, #non-vegetarian, #snacks, #beverages").show();
    }
    else if (checkVegetarian && !(checknonvegetarian) && checksnacks && !(checkbeverages)) {
        $("#vegetarian, #snacks").show();
        $("#non-vegetarian, #beverages").hide();
    }
    else if (checkVegetarian && !(checknonvegetarian) && checksnacks && checkbeverages) {
        $("#vegetarian, #snacks, #beverages").show();
        $("#non-vegetarian").hide();
    }
    else if (!(checkVegetarian) && checknonvegetarian && !(checksnacks) && !(checkbeverages)) {
        $("#vegetarian, #snacks, #beverages").hide();
        $("#non-vegetarian").show();
    }
    else if (!(checkVegetarian) && checknonvegetarian && checksnacks && !(checkbeverages)) {
        $("#vegetarian, #beverages").hide();
        $("#non-vegetarian, #snacks").show();
    }
    else if (!(checkVegetarian) && checknonvegetarian && checksnacks && checkbeverages) {
        $("#vegetarian").hide();
        $("#non-vegetarian, #snacks, #beverages").show();
    }
    else if (!(checkVegetarian) && checknonvegetarian && !(checksnacks) && checkbeverages) {
        $("#vegetarian, #snacks").hide();
        $("#non-vegetarian, #beverages").show();
    }
    else if (!(checkVegetarian) && !(checknonvegetarian) && checksnacks && !(checkbeverages)) {
        $("#vegetarian, #non-vegetarian, #beverages").hide();
        $("#snacks").show();
    }
    else if (!(checkVegetarian) && !(checknonvegetarian) && checksnacks && checkbeverages) {
        $("#vegetarian, #non-vegetarian").hide();
        $("#snacks, #beverages").show();
    }
    else if (!(checkVegetarian) && !(checknonvegetarian) && !(checksnacks) && checkbeverages) {
        $("#vegetarian, #non-vegetarian, #snacks").hide();
        $("#beverages").show();
    }
    else if (checkVegetarian && !(checknonvegetarian) && !(checksnacks) && checkbeverages) {
        $("#vegetarian, #beverages").show();
        $("#non-vegetarian, #snacks").hide();
    }
    else if (checkVegetarian && checknonvegetarian && !(checksnacks) && checkbeverages) {
        $("#vegetarian, #non-vegetarian, #beverages").show();
        $("#snacks").hide();
    }
});