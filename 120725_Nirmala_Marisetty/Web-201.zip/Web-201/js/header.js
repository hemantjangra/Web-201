window.onscroll = function () {
    navigation()
};
var navbar = $("#navbar");
var sticky = navbar.offset().top;

function navigation() {
    if (window.pageYOffset >= sticky) {
        navbar.addClass("sticky")
    } else {
        navbar.removeClass("sticky");
    }
}

$(".main").find("a").click(function(e) {
    e.preventDefault();
    var section = $(this).attr("href");
    $("html, body").animate({
        scrollTop: $(section).offset().top - 180
    });
});