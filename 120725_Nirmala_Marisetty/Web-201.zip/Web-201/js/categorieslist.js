// Get the data from firbase

var databaseRef = firebase.database().ref('fooditems/');
var categorie = 0;
databaseRef.once('value', function (snapshot) {
    snapshot.forEach(function (childSnapshot) {
        var data = childSnapshot.val();
        var key = childSnapshot.key;
        var heading, html, newHtml;
        heading = '<div id="%id%"><div class="categoriesname">' + key + '</div></div>';
        heading = heading.replace('%id%', key.toLowerCase());
        
        $('.categorieitems').append(heading);
        var items = '<div class="rightside" id="items_%id%"></div>';
        items = items.replace('%id%', categorie);
        var itemsid = "items_" + categorie;
        $('#'+key.toLowerCase()).append(items);
        categorie = categorie + 1;
        data.forEach(function (childData) {
            html = '<div class="list"><img alt="%imagealt%" class="list__img" src="%imagepath%"/>' +
                '<h3>%title%</h3><span>Price: &#8377;%price%</span><button class="btn home__btn">Add to Cart</button></div>';

            newHtml = html.replace('%imagealt%', childData.imagealt);
            newHtml = newHtml.replace('%imagepath%', childData.imagepath);
            newHtml = newHtml.replace('%price%', childData.price);
            newHtml = newHtml.replace('%title%', childData.title);
            $('#' + itemsid).append(newHtml);
        });
    });
});